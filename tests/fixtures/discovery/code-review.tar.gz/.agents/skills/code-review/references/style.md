# Review style

- Report facts before opinions.
- Name the file and line for every finding.
