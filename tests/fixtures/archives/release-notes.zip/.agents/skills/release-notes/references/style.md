# Style

Reference content inside the archived skill.
