---
name: release-notes
description: Summarize release notes.
---

# release-notes

Archived fixture used by the restore tests.
